# ------------------------------------------------------------------#
# Ohia Fungal Endophyte Analyses - Depends on "Process_Raw_Reads.R" #
# Author: Geoffrey Zahn                                             #
# ------------------------------------------------------------------#


# Packages ####

# source("https://bioconductor.org/biocLite.R")
# biocLite("BiocUpgrade")


# source("https://bioconductor.org/biocLite.R")
# biocLite("DESeq2")
library(DESeq2)
library(phyloseq); packageVersion("phyloseq")
library(ggplot2); packageVersion("ggplot2")
library(gridExtra)
library(ggpubr)
library(dada2); packageVersion("dada2")
library(stringr)
library(purrr)
library(corncob)
library(deseq2)
library(vegan)
library(dplyr)
library(reshape2)
library(ade4)
library(MASS)

# Load data ####
ps = readRDS(file = "./Output/clean_phyloseq_object.RDS")
meta=read.csv("metadata.csv")

# meta$IDENT = as.character(meta$IDENT)
# meta = meta[order(meta$IDENT),]
# 
# missing = row.names(sample_data(ps)[which(sample_names(ps) %in% meta$IDENT == FALSE)])
# ps = subset_samples(ps, "meta" != "o107")
# otus = otu_table(ps)
# taxa = tax_table(ps)
# 



# Remove empty ESVs and singletons and doublets ####
ps <- prune_taxa(colSums(otu_table(ps)) > 2, ps)


# Remove non-fungi ####
ps <- subset_taxa(ps, Kingdom == "k__Fungi")

# Remove NA values ####
ps = subset_samples(ps, Taxon != "#N/A")
# Remove any newly-empty samples ####
ps <- prune_samples(sample_sums(ps) != 0, ps)
# Sanity check
which(sample_sums(ps) == 0)
plot(taxa_sums(ps))
plot(sample_sums(ps))


# Merge Samples by . . .    ####
psm = merge_samples(ps, "Taxon")


# # merge by island AND Structure ####
# variable1 = as.character(get_variable(ps, "Structure"))
# variable2 = as.character(get_variable(ps, "Island"))
# 
# sample_data(ps)$NewPastedVar <- mapply(paste0, variable1, variable2, collapse = "_")
# psm2 = merge_samples(ps, "NewPastedVar")
# # remember this trick!

# repair merged values
sample_data(psm)$Taxon <- levels(sample_data(ps)$Taxon)
sample_data(psm)$Abaxial_Surface = plyr::mapvalues(sample_data(psm)$Abaxial_Surface, from = c(1,2), to=levels(sample_data(ps)$Abaxial_Surface) )
sample_data(ps)$Collection_Site


head(sample_data(psm))
 # Maybe?
# relative abundance transformation ####
psm_ra <- transform_sample_counts(psm, function(x) x / sum(x) )
ps_ra <- transform_sample_counts(ps, function(x) x / sum(x) )


# taxonomy table
tax = as.data.frame(ps_ra@tax_table)


# Bar plot of relative abundance, split by taxon ####
plot_bar(psm_ra, fill = "Phylum",x="Taxon") +
  geom_bar(stat = "identity") + coord_flip()  + #facet_wrap(~levels(sample_data(ps)$Structure)) +
  labs(x="Ohia Taxon",y="Relative Abundance")
ggsave("./Output/BarPlot_Fungal_Phylum_by_Tree.png", height = 8, width = 12, dpi=300)

plot_bar(psm_ra, fill = "Phylum",x="Taxon") +
  geom_bar(stat = "identity") + coord_flip()  + facet_wrap(~(sample_data(psm_ra)$Abaxial_Surface)) +
  labs(x="Site",y="Relative Abundance") + lims(y=c(0,1)) + theme_bw()
ggsave("./Output/BarPlot_Fungal_Phylum_by_Tree_and_Surface.png", height = 8, width = 12,dpi=300)

names(sample_data(ps))

# Summarise taxa and plot ####
source("./summarize_taxa_Joey711.R")
order_summary = summarize_taxa(ps,"Order","Collection_Site")
# Remove NAs
order_summary = order_summary[order_summary$Order != "NA",]
# reorder
setorder(order_summary, -meanRA)
# plot
ggplot(order_summary, aes(x= meanRA, y=Order, facet=Collection_Site)) +
  geom_point() + geom_errorbarh(aes(xmin=meanRA-sdRA,xmax=meanRA+sdRA)) + labs(x="Relative Abundance") +
  facet_grid(~Collection_Site) +
  theme_bw() + theme(panel.spacing = unit(2, "lines"))
ggsave("./Output/Summarized_taxa_Order_by_Site.png", height = 8, width = 10, dpi = 300)

order_summary = summarize_taxa(ps,"Order","Taxon")
# Remove NAs
order_summary = order_summary[order_summary$Order != "NA",]
# reorder
setorder(order_summary, -meanRA)
# plot
ggplot(order_summary, aes(x= meanRA, y=Order, facet=Taxon)) +
  geom_point() + geom_errorbarh(aes(xmin=meanRA-sdRA,xmax=meanRA+sdRA)) + labs(x="Relative Abundance") +
  facet_grid(~Taxon) +
  theme_bw() + theme(panel.spacing = unit(0.5, "lines"))
ggsave("./Output/Summarized_taxa_Order_by_Taxon.png", height = 8, width = 10, dpi = 300)

order_summary = summarize_taxa(ps,"Order","Elevation")
# Remove NAs
order_summary = order_summary[order_summary$Order != "NA",]
# reorder
setorder(order_summary, -meanRA)
# plot
ggplot(order_summary, aes(x= meanRA, y=Order, facet=Elevation)) +
  geom_point() + geom_errorbarh(aes(xmin=meanRA-sdRA,xmax=meanRA+sdRA)) + labs(x="Relative Abundance") +
  facet_grid(~Elevation) +
  theme_bw() + theme(panel.spacing = unit(0.5, "lines"))
ggsave("./Output/Summarized_taxa_Order_by_Elevation.png", height = 8, width = 10, dpi = 300)




# Taxonomy table ... frequency of each taxa (number of samples each taxon is found in) ####
taxtable = as.data.frame(table(tax_table(ps)))
write.csv(taxtable[order(taxtable$Freq, decreasing = TRUE),],
          "./Output/Most_Widespread_Taxa.csv", row.names = FALSE, quote = FALSE)


# Ordination ####
# Phyloseq method trying several ordination methods
NMDS = ordinate(ps_ra, method = "NMDS")
DCA = ordinate(ps_ra, method = "DCA")
CCA = ordinate(ps_ra, method = "CCA")
RDA = ordinate(ps_ra, method = "RDA")
MDS = ordinate(ps_ra, method = "MDS")
PCoA = ordinate(ps_ra, method = "PCoA")

# Plot them  ####
nmdsplot=plot_ordination(ps_ra, NMDS, color = "Collection_Site",shape = "Abaxial_Surface") + theme_minimal() + labs(color="Site",shape="Surface") + ggtitle("NMDS")
dcaplot=plot_ordination(ps_ra, DCA, color = "Collection_Site",shape = "Abaxial_Surface") + theme_minimal() + labs(color="Site",shape="Surface") + ggtitle("DCA")
ccaplot=plot_ordination(ps_ra, CCA, color = "Collection_Site",shape = "Abaxial_Surface") + theme_minimal() + labs(color="Site",shape="Surface") + ggtitle("CCA")
rdaplot=plot_ordination(ps_ra, RDA, color = "Collection_Site",shape = "Abaxial_Surface") + theme_minimal() + labs(color="Site",shape="Surface") + ggtitle("RDA")
mdsplot=plot_ordination(ps_ra, MDS, color = "Collection_Site",shape = "Abaxial_Surface") + theme_minimal() + labs(color="Site",shape="Surface") + ggtitle("MDS")
pcoaplot=plot_ordination(ps_ra, PCoA, color = "Collection_Site",shape = "Abaxial_Surface") + theme_minimal() + labs(color="Site",shape="Surface") + ggtitle("PCoA")

png(filename = "./Output/Ordination_Plots.png",height = 1000,width = 1000,res = 100)
grid.arrange(nmdsplot,dcaplot,ccaplot,rdaplot,mdsplot,pcoaplot)
dev.off()


#permanova ####
adonis.1 = adonis(otu_table(ps_ra) ~ sample_data(ps_ra)$Taxon +
                          sample_data(ps_ra)$Abaxial_Surface + 
                          sample_data(ps_ra)$Collection_Site)
adonis.2 = adonis(otu_table(ps_ra) ~ sample_data(ps_ra)$Taxon *
                    sample_data(ps_ra)$Abaxial_Surface * 
                    sample_data(ps_ra)$Collection_Site)


sink(file = "./Output/Stat-Tests.txt", append = TRUE)
print("PermANOVA -- Additive")
adonis.1
print("PermANOVA -- Interactive")
adonis.2
sink(NULL)


AIC(adonis.1,adonis.2)
# Mantel Test ####

spatial.dist = dist(cbind(ps_ra@sam_data$LONG, ps_ra@sam_data$LAT))
comm.dist =   vegdist(as.matrix(ps_ra@otu_table))

mantel.test = mantel.rtest(spatial.dist, comm.dist, nrepet = 9999)

sink(file = "./Output/Stat-Tests.txt", append = TRUE)
print("MANTEL TEST")
mantel.test
sink(NULL)

png("./Output/Mantel_Plot.png")
plot(mantel.test)
dev.off()

# Rarefaction analyses ####
rarecurve(ps@otu_table)

# Diversity analyses ####

shannon = diversity(ps@otu_table)

div_aov = aov(shannon ~ ps@sam_data$Taxon * ps@sam_data$ALTITUDE)
sink(file = "./Output/Stat-Tests.txt", append = TRUE)
print("")
print("Shannon Diversity ANOVA - Taxon*Altitude")
summary(div_aov)
sink(NULL)

ggplot(mapping = aes(x=ps@sam_data$Taxon,y=shannon, fill = ps@sam_data$Taxon)) +
  geom_boxplot() + theme_minimal() + labs(x="Taxon", fill="Taxon",y="Shannon Diversity") +
  theme(axis.text.x = element_text(angle=90))
ggsave("./Output/Shannon_Diversity_by_Taxon.png", dpi=300)


# Model comparisons for Shannon diversity as dependent variable ####

mod = data.frame(Shannon = shannon, Altitude = meta$ALTITUDE,Taxon=meta$Taxon,Site=meta$Collection_Site,
           Elevation=meta$Elevation,Surface=meta$Abaxial_Surface)
names(mod)

sink(file = "./Output/Stat-Tests.txt", append = TRUE)
print("Model Selection for Shannon Diversity")
m1 = aov(Shannon ~ Altitude+Taxon*Site+Elevation+Surface, data = mod)
summary(m1)
m2 = aov(Shannon ~ Surface+Taxon+Site, data = mod)
summary(m2)
print("Stepwise AIC")
stepAIC(m1,scope = ~Altitude+Taxon*Site+Elevation+Surface)
print("Best model for Diversity looks to be ~Altitude+Taxon+Site")
sink(NULL)

# Plot of Shannon vs altitude+taxon ####
ggplot(mod, aes(x=Altitude,y=Shannon, color=Taxon)) +
  geom_point() + stat_smooth(se=FALSE, method = "lm") +
  theme_bw() + labs(x="Elevation (m)",y="Shannon Diversity")
ggsave("Output/Diversity_vs_Altitude_w_Taxon.png", dpi=300)

# Taxonomy tables and qualitative analyses ####
taxtab = sort(table(tax_table(ps)), decreasing = TRUE)
head(taxtab, 30)
